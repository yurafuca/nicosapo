Class NicoLive
{
    constructor() {
        // do nothing.
    }
}